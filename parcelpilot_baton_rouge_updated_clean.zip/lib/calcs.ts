import area from "@turf/area";
import buffer from "@turf/buffer";
import { polygon as turfPolygon, Feature, Polygon } from "@turf/helpers";
import cleanCoords from "@turf/clean-coords";

export const ftToM = (ft: number) => ft * 0.3048;

export function buildableEnvelope(parcel: Feature<Polygon>, uniformSetbackFt: number) {
  const m = ftToM(uniformSetbackFt);
  const buff = buffer(parcel, -m, { units: "meters" });
  if (!buff) return null;
  return cleanCoords(buff as Feature<Polygon>);
}

export function estimateParkingStalls(pavedAreaSqft: number) {
  return Math.floor(pavedAreaSqft / 330);
}

export function areaSqft(geojson: Feature<Polygon>) {
  const m2 = area(geojson);
  return m2 * 10.7639;
}

export function makePolygon(coords: number[][]) {
  const head = coords[0], tail = coords[coords.length - 1];
  const looped = (head[0] === tail[0] && head[1] === tail[1]) ? coords : coords.concat([coords[0]]);
  return turfPolygon([looped]) as any;
}
