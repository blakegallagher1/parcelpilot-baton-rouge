import { Feature, LineString, Polygon } from "geojson";
import { lineString as turfLineString } from "@turf/helpers";
import buffer from "@turf/buffer";
import union from "@turf/union";
import difference from "@turf/difference";
import cleanCoords from "@turf/clean-coords";
import booleanValid from "@turf/boolean-valid";

export type DirectionalSetbacks = { frontFt:number; sideFt:number; rearFt:number; };
const ftToM = (ft:number)=> ft * 0.3048;

function edgePairs(coords: number[][]) {
  const pairs: [number[], number[]][] = [];
  for (let i=0; i<coords.length-1; i++) pairs.push([coords[i], coords[i+1]]);
  return pairs;
}

export function directionalEnvelope(parcel: Feature<Polygon>, frontEdgeIndex: number, s: DirectionalSetbacks): Feature<Polygon> | null {
  const coords = parcel.geometry.coordinates[0];
  const pairs = edgePairs(coords);
  if (pairs.length < 3) return null;

  const n = pairs.length;
  const rearIndex = (frontEdgeIndex + Math.floor(n/2)) % n;
  const sideIdx = new Set<number>(pairs.map((_,i)=>i));
  sideIdx.delete(frontEdgeIndex);
  sideIdx.delete(rearIndex);

  let subtractPoly: any = null;

  function addBand(indices: number[], ft: number) {
    if (ft <= 0) return;
    let merged: any = null;
    for (const i of indices) {
      const ln = turfLineString(pairs[i]) as Feature<LineString>;
      const band = buffer(ln, ftToM(ft), { units: "meters" }) as any;
      merged = merged ? union(merged, band) : band;
    }
    subtractPoly = subtractPoly ? union(subtractPoly, merged) : merged;
  }

  addBand([frontEdgeIndex], s.frontFt);
  addBand([rearIndex], s.rearFt);
  addBand(Array.from(sideIdx), s.sideFt);

  if (!subtractPoly) return parcel;

  const diff = difference(parcel as any, subtractPoly as any) as any;
  if (!diff) return null;
  const cleaned = cleanCoords(diff);
  if (!booleanValid(cleaned)) return cleaned as any;
  return cleaned as any;
}
