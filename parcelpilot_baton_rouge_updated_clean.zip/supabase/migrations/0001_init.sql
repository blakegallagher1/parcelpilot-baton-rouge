create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text unique,
  created_at timestamptz default now()
);

create table if not exists credits (
  user_id uuid primary key references auth.users(id) on delete cascade,
  balance int not null default 3,
  updated_at timestamptz default now()
);

create table if not exists reports (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  zoning_json jsonb not null,
  parcel_geojson jsonb not null,
  metrics jsonb,
  image_url text,
  pdf_url text,
  created_at timestamptz default now()
);
