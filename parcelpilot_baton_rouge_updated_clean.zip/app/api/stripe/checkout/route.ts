import { NextRequest, NextResponse } from "next/server";
import { stripe, PRICES } from "@/lib/stripe";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const plan = searchParams.get("plan");
  const price = plan === "sub" ? PRICES.SUB : PRICES.ONEOFF;
  if (!price) return NextResponse.json({ ok:false, error: "Price not configured" }, { status: 400 });

  const origin = process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3000";
  const session = await stripe.checkout.sessions.create({
    mode: plan === "sub" ? "subscription" : "payment",
    line_items: [{ price, quantity: 1 }],
    success_url: `${origin}/dashboard?checkout=success`,
    cancel_url: `${origin}/dashboard?checkout=cancel`
  });

  return NextResponse.redirect(session.url!, 302);
}
