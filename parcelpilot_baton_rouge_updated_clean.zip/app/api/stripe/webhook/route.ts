import { NextRequest, NextResponse } from "next/server";
import { stripe } from "@/lib/stripe";
import { supabaseAdmin } from "@/lib/supabase";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const sig = req.headers.get("stripe-signature");
  const whSecret = process.env.STRIPE_WEBHOOK_SECRET!;
  const buf = Buffer.from(await req.arrayBuffer());

  let event;
  try {
    event = stripe.webhooks.constructEvent(buf, sig as string, whSecret);
  } catch (err:any) {
    console.error(err);
    return NextResponse.json({ received: false }, { status: 400 });
  }

  const sb = supabaseAdmin();

  if (event.type === "checkout.session.completed") {
    const session: any = event.data.object;
    const email = session.customer_details?.email;
    if (email) {
      const { data: user } = await sb.auth.admin.getUserByEmail(email);
      if (user?.user) {
        const isSub = session.mode === "subscription" || !!session.subscription;
        const delta = isSub ? 200 : 10;
        await sb.from("credits").upsert({ user_id: user.user.id, balance: delta }, { onConflict: "user_id" });
      }
    }
  }

  if (event.type === "customer.subscription.updated") {
    // Optional monthly refill logic
  }

  return NextResponse.json({ received: true });
}
