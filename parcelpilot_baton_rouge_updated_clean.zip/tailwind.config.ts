import type { Config } from "tailwindcss";
import { fontFamily } from "tailwindcss/defaultTheme";

const config: Config = {
  darkMode: ["class"],
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      fontFamily: { sans: ["Inter", ...fontFamily.sans] },
      backgroundImage: { grid: "radial-gradient(currentColor 1px, transparent 1px)" },
      backgroundSize: { grid: "24px 24px" }
    }
  },
  plugins: [require("tailwindcss-animate")]
};
export default config;
