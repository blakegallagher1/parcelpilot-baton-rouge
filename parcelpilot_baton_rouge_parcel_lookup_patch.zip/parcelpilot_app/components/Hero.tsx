import Link from "next/link";
import Logo from "./Logo";

export default function Hero() {
  return (
    <section className="relative gradient">
      <div className="mx-auto max-w-6xl px-6 py-24">
        <div className="flex items-center justify-between">
          <Logo className="text-white/90" />
          <Link href="/dashboard" className="btn btn-primary">Open App</Link>
        </div>
        <div className="mt-24 grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-5xl md:text-6xl font-semibold leading-tight">
              Generate <span className="text-cyan-400">Site Plans</span> from Zoning in Minutes
            </h1>
            <p className="mt-6 text-white/70 max-w-xl">
              Draw your parcel, pick a Baton Rouge preset or upload the zoning PDF, and let Gemini 2.5 Flash Image render a clean plan.
            </p>
            <div className="mt-8 flex gap-3">
              <Link href="/dashboard" className="btn btn-primary">Try Free (3 credits)</Link>
              <a href="#how" className="btn btn-muted">How it works</a>
            </div>
          </div>
          <div className="glass p-4 md:p-6">
            <img src="/preview.png" alt="Preview" className="rounded-lg w-full h-auto" />
          </div>
        </div>
        <div id="how" className="mt-24 grid md:grid-cols-3 gap-6">
          {[
            ["Sketch Parcel","Draw polygon & compute area with Turf."],
            ["Set Zoning","Pick Baton Rouge preset or parse PDF."],
            ["Generate Plan","Gemini renders a labeled site plan."]
          ].map(([t,s],i)=>(
            <div key={i} className="glass p-6">
              <div className="text-white/60">{i+1}</div>
              <h3 className="text-xl font-medium mt-2">{t}</h3>
              <p className="text-white/70 mt-2">{s}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
