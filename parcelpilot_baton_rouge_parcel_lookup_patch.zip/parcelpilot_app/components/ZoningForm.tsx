"use client";
import { useState, useEffect } from "react";
import { BR_PRESETS, getPreset } from "@/lib/presets";

export type ZoningSpec = {
  zoneName?: string;
  setbacks: { frontFt:number; sideFt:number; rearFt:number; } ;
  maxHeightFt?: number;
  far?: number | null;
  lotCoveragePct?: number | null;
  parkingRatioPer1000sf?: number | null;
};

type Props = { onChange: (z: ZoningSpec)=>void; value?: ZoningSpec | null };

export default function ZoningForm({onChange, value}:Props) {
  // Default spec used when the form first mounts and no value is provided
  const defaultSpec: ZoningSpec = {
    setbacks: { frontFt: 20, sideFt: 10, rearFt: 20 },
    maxHeightFt: 60,
    far: 2.5,
    lotCoveragePct: 70,
    parkingRatioPer1000sf: 4,
  };
  const [spec, setSpec] = useState<ZoningSpec>(value ?? defaultSpec);

  // When the parent passes a new value, update the local state accordingly
  // so that the form reflects the preset. Only updates when value changes.
  useEffect(() => {
    if (value) {
      setSpec(value);
      onChange(value);
    }
  }, [value]);

  function update<K extends keyof ZoningSpec>(k:K, v:any) {
    const next = { ...spec, [k]: v };
    setSpec(next); onChange(next);
  }
  function updateSetback(k: keyof ZoningSpec["setbacks"], v:number) {
    const next = { ...spec, setbacks: { ...spec.setbacks, [k]: v } };
    setSpec(next); onChange(next);
  }

  return (
    <div className="glass p-4 md:p-6 space-y-3">
      <div>
        <label>Baton Rouge Presets</label>
        <select onChange={(e)=>{
          const code = e.target.value;
          if (!code) return;
          const p = getPreset(code);
          if (!p) return;
          const next: ZoningSpec = {
            zoneName: p.code,
            setbacks: p.defaults.setbacks,
            maxHeightFt: p.defaults.maxHeightFt ?? undefined,
            far: p.defaults.far ?? null,
            lotCoveragePct: p.defaults.lotCoveragePct ?? null,
            parkingRatioPer1000sf: p.defaults.parkingRatioPer1000sf ?? null
          };
          setSpec(next); onChange(next);
        }} className="w-full">
          <option value="">Select (LC1/LC2/HC1/HC2/C5/NO/NC/C1/C2)</option>
          {BR_PRESETS.map(p=> <option key={p.code} value={p.code}>{p.label}</option>)}
        </select>
        <p className="text-xs text-white/60 mt-1">Source: Baton Rouge / EBR UDC — Ch. 11 (Table 11.G). Confirm overlays.</p>
      </div>

      <div className="grid md:grid-cols-3 gap-3">
        <div>
          <label>Zone Name</label>
          <input placeholder="e.g., LC2" value={spec.zoneName ?? ""} onChange={e=>update("zoneName", e.target.value)} />
        </div>
        <div>
          <label>FAR</label>
          <input type="number" step="0.1" value={spec.far ?? 0} onChange={e=>update("far", Number(e.target.value)||null)} />
        </div>
        <div>
          <label>Max Height (ft)</label>
          <input type="number" value={spec.maxHeightFt ?? 0} onChange={e=>update("maxHeightFt", Number(e.target.value)||0)} />
        </div>
      </div>
      <div className="grid md:grid-cols-3 gap-3">
        <div>
          <label>Front Setback (ft)</label>
          <input type="number" value={spec.setbacks.frontFt} onChange={e=>updateSetback("frontFt", Number(e.target.value))} />
        </div>
        <div>
          <label>Side Setback (ft)</label>
          <input type="number" value={spec.setbacks.sideFt} onChange={e=>updateSetback("sideFt", Number(e.target.value))} />
        </div>
        <div>
          <label>Rear Setback (ft)</label>
          <input type="number" value={spec.setbacks.rearFt} onChange={e=>updateSetback("rearFt", Number(e.target.value))} />
        </div>
      </div>
      <div className="grid md:grid-cols-2 gap-3">
        <div>
          <label>Lot Coverage (%)</label>
          <input type="number" value={spec.lotCoveragePct ?? 0} onChange={e=>update("lotCoveragePct", Number(e.target.value)||null)} />
        </div>
        <div>
          <label>Parking Ratio (per 1,000 sf)</label>
          <input type="number" value={spec.parkingRatioPer1000sf ?? 0} onChange={e=>update("parkingRatioPer1000sf", Number(e.target.value)||null)} />
        </div>
      </div>
      <div className="pt-2 text-sm text-white/60">
        Or <button onClick={()=>document.getElementById('zoning-pdf')?.click()}
          className="underline decoration-dotted underline-offset-4">upload a zoning PDF</button> for AI extraction.
        <input id="zoning-pdf" type="file" accept="application/pdf" hidden onChange={async (e)=>{
          const file = e.target.files?.[0]; if (!file) return;
          const fd = new FormData(); fd.append("file", file);
          const res = await fetch("/api/parse-zoning", { method: "POST", body: fd });
          const j = await res.json();
          if (j.ok && j.data) { setSpec(j.data); onChange(j.data); } else { alert(j.error || "Could not parse zoning PDF"); }
        }}/>
      </div>
    </div>
  );
}
