"use client";
import { useState, useEffect } from "react";
import { supabaseBrowser } from "@/lib/supabase-browser";
import { ZoningSpec } from "./ZoningForm";
import { Feature, Polygon } from "geojson";

type Props = {
  parcel: Feature<Polygon> | null;
  zoning: ZoningSpec | null;
  snapshot?: string | null;
  frontEdge?: number | null;
};

export default function GeneratePanel({parcel, zoning, snapshot, frontEdge}:Props) {
  const [loading, setLoading] = useState(false);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [canGenerate, setCanGenerate] = useState(false);
  const [credits, setCredits] = useState<number | null>(null);
  const sb = supabaseBrowser();

  useEffect(()=>{
    (async()=>{
      const { data: { session } } = await sb.auth.getSession();
      if (!session) { setCanGenerate(false); setCredits(null); return; }
      const res = await fetch('/api/me', { headers: { Authorization: `Bearer ${session.access_token}` } });
      const j = await res.json();
      if (j.ok) { setCredits(j.credits); setCanGenerate(j.credits>0); }
    })();
  }, [sb]);

  async function generate() {
    if (!parcel || !zoning) return alert("Add parcel + zoning");
    const { data: { session } } = await sb.auth.getSession();
    if (!session) return alert('Sign in to generate');
    setLoading(true); setImageUrl(null);
    const res = await fetch("/api/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${session.access_token}` },
      body: JSON.stringify({ parcel, zoning, snapshot, frontEdge })
    });
    const j = await res.json();
    setLoading(false);
    if (j.ok) {
      setImageUrl(j.imageUrl);
      const me = await fetch('/api/me', { headers: { Authorization: `Bearer ${session.access_token}` } });
      const jj = await me.json();
      if (jj.ok) { setCredits(jj.credits); setCanGenerate(jj.credits>0); }
    } else alert(j.error || "Failed");
  }

  return (
    <div className="glass p-4 md:p-6">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h3 className="text-lg font-medium">3) Generate Site Plan</h3>
          <p className="text-white/60 text-sm">1 credit per image. Trial includes 3 credits.</p>
        </div>
        <div className="flex flex-wrap gap-3">
          <a href="/api/stripe/checkout?plan=oneoff" className="btn btn-muted">Buy 10 Credits</a>
          <a href="/api/stripe/checkout?plan=sub" className="btn btn-primary">Go Pro (Monthly)</a>
        </div>
      </div>
      <div className="mt-4">
        <button disabled={loading || !canGenerate} onClick={generate} className="btn btn-primary">
          {loading ? "Generating..." : (canGenerate?`Generate${credits!=null?` (${credits} left)`:''}`:"Sign in / add credits")}
        </button>
      </div>
      {imageUrl && (
        <div className="mt-4">
          <img src={imageUrl} alt="Site plan" className="rounded-lg w-full h-auto border border-white/10" />
          <div className="mt-2 flex gap-3">
            <a href={imageUrl} download className="btn btn-muted">Download PNG</a>
            <a href={`/api/report?image=${encodeURIComponent(imageUrl)}`} className="btn btn-muted">Download PDF Report</a>
          </div>
        </div>
      )}
    </div>
  );
}
