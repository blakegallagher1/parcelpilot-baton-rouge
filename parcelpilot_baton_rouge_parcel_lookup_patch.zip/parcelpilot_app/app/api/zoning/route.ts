import { NextRequest, NextResponse } from "next/server";

/*
 * POST /api/zoning
 *
 * Determine the zoning district(s) for a given parcel polygon by
 * intersecting it with the official zoning layer provided by EBRGIS.
 * The client should send a JSON body with a `polygon` property
 * containing GeoJSON coordinates (an array of rings where each ring is
 * an array of [lng, lat] pairs). This endpoint returns the first
 * intersecting ZONING_TYPE (if any) and indicates success or error.
 *
 * Environment variables used:
 *   NEXT_PUBLIC_EBRGIS_BASE   – base URL for the ArcGIS REST services
 *   EBRGIS_ZONING_SERVICE     – path to the zoning map service layer (e.g. "/Cadastral/Zoning/MapServer/0")
 */

const BASE = process.env.NEXT_PUBLIC_EBRGIS_BASE || "https://maps.brla.gov/gis/rest/services";
const ZONING = process.env.EBRGIS_ZONING_SERVICE || "/Cadastral/Zoning/MapServer/0";

async function arcgisQuery(url: string, params: Record<string, string>) {
  const searchParams = new URLSearchParams({ f: "json", ...params });
  const res = await fetch(`${url}?${searchParams.toString()}`, { cache: "no-store" });
  if (!res.ok) {
    throw new Error(`ArcGIS query failed: ${res.status}`);
  }
  const data = await res.json();
  if (data.error) {
    throw new Error(data.error.message || "ArcGIS error");
  }
  return data;
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const polygon = body?.polygon;
    if (!polygon || !polygon.coordinates || !Array.isArray(polygon.coordinates)) {
      return NextResponse.json({ ok: false, error: "Invalid polygon" }, { status: 400 });
    }
    // Convert GeoJSON polygon to ArcGIS rings: geometry expects an array of rings
    // Each ring is an array of [x,y] coordinates (lon,lat). We'll pass through as provided.
    const rings = polygon.coordinates;
    const url = `${BASE}${ZONING}/query`;
    const resp = await arcgisQuery(url, {
      geometry: JSON.stringify({ rings }),
      geometryType: "esriGeometryPolygon",
      inSR: "4326",
      spatialRel: "esriSpatialRelIntersects",
      outFields: "ZONING_TYPE",
      returnGeometry: "false",
      outSR: "4326",
      resultRecordCount: "1",
    });
    if (!resp.features || resp.features.length === 0) {
      return NextResponse.json({ ok: false, error: "No zoning found" }, { status: 404 });
    }
    const zone = resp.features[0].attributes?.ZONING_TYPE;
    if (!zone) {
      return NextResponse.json({ ok: false, error: "Zone attribute missing" }, { status: 500 });
    }
    return NextResponse.json({ ok: true, zone });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Server error" }, { status: 500 });
  }
}