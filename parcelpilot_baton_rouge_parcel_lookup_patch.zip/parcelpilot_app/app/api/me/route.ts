import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  const auth = req.headers.get("authorization");
  const token = auth?.split("Bearer ")[1];
  if (!token) return NextResponse.json({ ok:false }, { status: 401 });

  const sb = supabaseAdmin();
  const { data: userData } = await sb.auth.getUser(token);
  const user = userData?.user;
  if (!user) return NextResponse.json({ ok:false }, { status: 401 });

  const { data } = await sb.from("credits").select("balance").eq("user_id", user.id).single();
  const credits = data?.balance ?? 0;
  return NextResponse.json({ ok:true, credits });
}
