import { NextRequest, NextResponse } from "next/server";
import pdfParse from "pdf-parse";
import { genai, MODELS } from "@/lib/gemini";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  try {
    const form = await req.formData();
    const file = form.get("file") as File | null;
    if (!file) return NextResponse.json({ ok: false, error: "No file" }, { status: 400 });
    const buf = Buffer.from(await file.arrayBuffer());
    const data = await pdfParse(buf);
    const text = data.text.slice(0, 100_000);

    const ai = genai();
    const model = ai.getGenerativeModel({ model: MODELS.TEXT });

    const schema = {
      type: "object",
      properties: {
        zoneName: { type: "string" },
        setbacks: {
          type: "object",
          properties: {
            frontFt: { type: "number" },
            sideFt: { type: "number" },
            rearFt: { type: "number" }
          },
          required: ["frontFt","sideFt","rearFt"]
        },
        maxHeightFt: { type: "number" },
        far: { type: "number" },
        lotCoveragePct: { type: "number" },
        parkingRatioPer1000sf: { type: "number" }
      },
      required: ["setbacks"]
    };

    const prompt = `Extract a concise zoning spec JSON from the provided zoning ordinance text.
- Only include fields present with numeric values in feet or ratios.
- Convert meters to feet if needed. No comments, just JSON.
`;

    const response = await model.generateContent({
      contents: [{ role: "user", parts: [{ text: prompt + "\nZONING TEXT:\n" + text }] }],
      generationConfig: {
        responseMimeType: "application/json",
        responseSchema: schema as any
      }
    });

    const raw = response.response.text();
    let json;
    try { json = JSON.parse(raw); } catch { json = null; }
    if (!json) return NextResponse.json({ ok: false, error: "AI parse failed" }, { status: 400 });
    return NextResponse.json({ ok: true, data: json });
  } catch (e:any) {
    console.error(e);
    return NextResponse.json({ ok: false, error: e.message }, { status: 500 });
  }
}
