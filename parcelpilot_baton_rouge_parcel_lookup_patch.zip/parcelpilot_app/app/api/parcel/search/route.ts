import { NextRequest, NextResponse } from "next/server";

/*
 * POST /api/parcel/search
 *
 * Look up an address in East Baton Rouge Parish using the official
 * EBRGIS address points layer, then intersect that point with the
 * assessor's parcel layer to return the parcel polygon and minimal
 * attributes. This proxy exists so that sensitive API keys are not
 * exposed to the browser and to normalize error handling. The API
 * expects a JSON body with a single property `address` (string).
 *
 * Environment variables used:
 *   NEXT_PUBLIC_EBRGIS_BASE – base URL for the ArcGIS REST services
 *   EBRGIS_PARCEL_SERVICE    – path to the parcel map service layer (e.g. "/Cadastral/Tax_Parcel/MapServer/0")
 *   EBRGIS_ADDRESS_SERVICE   – path to the address points feature layer (e.g. "/Addressing/Street_Address/MapServer/0")
 */

const BASE = process.env.NEXT_PUBLIC_EBRGIS_BASE || "https://maps.brla.gov/gis/rest/services";
const PARCEL = process.env.EBRGIS_PARCEL_SERVICE || "/Cadastral/Tax_Parcel/MapServer/0";
const ADDRESS = process.env.EBRGIS_ADDRESS_SERVICE || "/Addressing/Street_Address/MapServer/0";

/**
 * Helper to perform an ArcGIS REST query and return the parsed JSON.
 */
async function arcgisQuery(url: string, params: Record<string, string>) {
  const searchParams = new URLSearchParams({ f: "json", ...params });
  const res = await fetch(`${url}?${searchParams.toString()}`, { cache: "no-store" });
  if (!res.ok) {
    throw new Error(`ArcGIS query failed: ${res.status}`);
  }
  const data = await res.json();
  if (data.error) {
    throw new Error(data.error.message || "ArcGIS error");
  }
  return data;
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const address = (body?.address || "").toString().trim();
    if (!address || address.length < 3) {
      return NextResponse.json({ ok: false, error: "Invalid address" }, { status: 400 });
    }
    // Step 1: query address points with a case-insensitive LIKE on FULL_ADDRESS
    const addrUrl = `${BASE}${ADDRESS}/query`;
    // Escape single quotes for SQL-like string
    const safe = address.replace(/'/g, "''");
    const where = `UPPER(FULL_ADDRESS) LIKE UPPER('%${safe}%')`;
    const addrResp = await arcgisQuery(addrUrl, {
      where,
      outFields: "OBJECTID,FULL_ADDRESS,STATUS",
      returnGeometry: "true",
      outSR: "4326",
      resultRecordCount: "1",
      orderByFields: "STATUS ASC",
    });
    if (!addrResp.features || addrResp.features.length === 0) {
      return NextResponse.json({ ok: false, error: "No address match found" }, { status: 404 });
    }
    const addrFeature = addrResp.features[0];
    const geom = addrFeature.geometry || {};
    const x = geom.x as number;
    const y = geom.y as number;
    if (typeof x !== "number" || typeof y !== "number") {
      return NextResponse.json({ ok: false, error: "No point geometry for address" }, { status: 500 });
    }
    // Step 2: intersect with parcel layer
    const parcelUrl = `${BASE}${PARCEL}/query`;
    const parcelResp = await arcgisQuery(parcelUrl, {
      geometry: JSON.stringify({ x, y, spatialReference: { wkid: 4326 } }),
      geometryType: "esriGeometryPoint",
      inSR: "4326",
      spatialRel: "esriSpatialRelIntersects",
      outFields: "OBJECTID,PARCELID,GPIN,OWNER,ASSESSED,LANDUSE,ACRES",
      returnGeometry: "true",
      outSR: "4326",
    });
    if (!parcelResp.features || parcelResp.features.length === 0) {
      return NextResponse.json({ ok: false, error: "No parcel found at that location" }, { status: 404 });
    }
    const p = parcelResp.features[0];
    const rings = p.geometry?.rings;
    if (!rings || rings.length === 0) {
      return NextResponse.json({ ok: false, error: "Parcel geometry missing" }, { status: 500 });
    }
    // Convert rings to GeoJSON coordinates (ArcGIS uses [x,y] = [lon,lat])
    const coords = rings.map((ring: any[][]) => ring.map(([lng, lat]: number[]) => [lng, lat]));
    const feature = {
      type: "Feature" as const,
      geometry: { type: "Polygon" as const, coordinates: coords },
      properties: {
        parcelId: p.attributes?.PARCELID ?? p.attributes?.GPIN ?? p.attributes?.OBJECTID,
        owner: p.attributes?.OWNER ?? null,
        assessed: p.attributes?.ASSESSED ?? null,
        landUse: p.attributes?.LANDUSE ?? null,
        acres: p.attributes?.ACRES ?? null,
        source: "EBRGIS",
      },
    };
    return NextResponse.json({ ok: true, candidateAddress: addrFeature.attributes?.FULL_ADDRESS ?? address, point: { x, y }, parcel: feature });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e.message || "Server error" }, { status: 500 });
  }
}