"use client";
import { useState, useEffect } from "react";
import { supabaseBrowser } from "@/lib/supabase-browser";
import ParcelMap from "@/components/ParcelMap";
import ZoningForm, { ZoningSpec } from "@/components/ZoningForm";
import { getPreset } from "@/lib/presets";
import GeneratePanel from "@/components/GeneratePanel";
import AuthPanel from "@/components/AuthPanel";
import { Feature, Polygon } from "geojson";

export default function Dashboard() {
  const [parcel, setParcel] = useState<Feature<Polygon> | null>(null);
  const [zoning, setZoning] = useState<ZoningSpec | null>(null);
  const [snapshot, setSnapshot] = useState<string | null>(null);
  const [frontEdge, setFrontEdge] = useState<number | null>(null);
  const sb = supabaseBrowser();

  // When a parcel is defined, look up the zoning district from the GIS
  // service and pre-populate the zoning form using available presets. If
  // there is no matching preset, default setbacks and blank values are
  // used. This effect runs whenever the parcel changes.
  useEffect(() => {
    (async () => {
      if (!parcel) return;
      try {
        const res = await fetch("/api/zoning", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ polygon: parcel.geometry }),
        });
        const j = await res.json();
        if (j.ok && j.zone) {
          const p = getPreset(j.zone);
          let spec: ZoningSpec;
          if (p) {
            spec = {
              zoneName: p.code,
              setbacks: p.defaults.setbacks,
              maxHeightFt: p.defaults.maxHeightFt ?? undefined,
              far: p.defaults.far ?? null,
              lotCoveragePct: p.defaults.lotCoveragePct ?? null,
              parkingRatioPer1000sf: p.defaults.parkingRatioPer1000sf ?? null,
            };
          } else {
            // fallback: use generic values
            spec = {
              zoneName: j.zone,
              setbacks: { frontFt: 20, sideFt: 10, rearFt: 20 },
              maxHeightFt: undefined,
              far: null,
              lotCoveragePct: null,
              parkingRatioPer1000sf: null,
            };
          }
          setZoning(spec);
        }
      } catch (e) {
        console.error(e);
      }
    })();
    // We only want to run this effect when the parcel changes.
  }, [parcel]);

  // Handle magic link exchange
  useEffect(()=>{
    (async()=>{
      const url = new URL(window.location.href);
      const code = url.searchParams.get('code');
      if (code) {
        const { error } = await sb.auth.exchangeCodeForSession({ code });
        if (!error) {
          url.searchParams.delete('code'); url.searchParams.delete('type');
          window.history.replaceState({}, '', url.toString());
        }
      }
    })();
  }, []);

  return (
    <div className="mx-auto max-w-6xl px-6 py-10">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">ParcelPilot</h1>
        <AuthPanel />
      </div>
      <p className="text-white/70 mt-2">Sketch your parcel, set zoning (presets or PDF), choose street edge, generate plan.</p>
      <div className="mt-6 grid md:grid-cols-2 gap-6">
        <div className="glass p-4 md:p-6">
          <h3 className="text-lg font-medium">1) Parcel</h3>
          <p className="text-white/60 text-sm">Draw a polygon on the map, then choose the street edge.</p>
          <div className="mt-3">
            <ParcelMap onChange={setParcel} onSnapshot={setSnapshot} onFrontEdge={setFrontEdge} />
          </div>
        </div>
        <div>
          <h3 className="text-lg font-medium mb-3">2) Zoning</h3>
          <ZoningForm onChange={setZoning} value={zoning} />
        </div>
      </div>
      <div className="mt-6">
        <GeneratePanel parcel={parcel} zoning={zoning} snapshot={snapshot} frontEdge={frontEdge} />
      </div>
    </div>
  );
}
