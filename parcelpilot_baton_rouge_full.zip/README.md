# ParcelPilot – AI Site Plan Generator (Gemini 2.5 Flash Image “Nano Banana”)

Generate polished, conceptual **site plans** from a parcel polygon + zoning rules.

**What you get**
- Draw parcel on a modern MapLibre map (with canvas snapshot).
- Paste zoning values *or upload the zoning PDF* for AI extraction.
- **Baton Rouge presets** (LC1/LC2/LC3/HC1/HC2/C5/NO/NC + C1/C2 legacy).
- **Directional envelope** (front/side/rear setbacks) using a street-edge picker.
- **Stripe** payments (one‑off credits + monthly subscription) with webhook crediting.
- **Supabase** Auth/DB/Storage, credits enforced server‑side.
- **Gemini 2.5 Flash Image** (“nano banana”) renders a top‑down labeled 2D plan.

> Conceptual only; not for permitting or construction.

## Quick Start

```bash
npm install
cp .env.example .env.local
# Fill env vars (Gemini, Supabase, Stripe, MapTiler)
npm run dev
```

**Deploy:** Vercel → add env vars → set Stripe webhook to `/api/stripe/webhook`.

## Env

```ini
NEXT_PUBLIC_APP_URL=http://localhost:3000

GEMINI_API_KEY=

NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=

STRIPE_SECRET_KEY=
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=
STRIPE_PRICE_ONEOFF=
STRIPE_PRICE_SUBSCRIPTION=
STRIPE_WEBHOOK_SECRET=

NEXT_PUBLIC_MAPTILER_KEY=

MAX_IMAGE_PIXELS=1024
```

## Screens
- **Dashboard:** Parcel ▸ Zoning (presets/PDF) ▸ Generate (credits & download).

## Notes
- Baton Rouge numbers derive from UDC Chapter 11 Table 11.G; verify project overlays (Major Street Plan, design districts). Outputs are conceptual.
