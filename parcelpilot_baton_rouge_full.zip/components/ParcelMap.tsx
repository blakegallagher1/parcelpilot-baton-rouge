"use client";

import maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";
import { MaplibreTerradrawControl } from "@watergis/maplibre-gl-terradraw";
import "@watergis/maplibre-gl-terradraw/dist/maplibre-gl-terradraw.css";
import { useEffect, useRef, useState } from "react";
import { Feature, Polygon } from "geojson";
import { areaSqft } from "@/lib/calcs";

type Props = {
  onChange: (f: Feature<Polygon> | null)=>void;
  onSnapshot?: (dataUrl: string | null)=>void;
  onFrontEdge?: (index: number | null)=>void;
};

export default function ParcelMap({onChange, onSnapshot, onFrontEdge}: Props) {
  const mapContainer = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<maplibregl.Map | null>(null);
  const [sqft, setSqft] = useState<number | null>(null);
  const [frontMode, setFrontMode] = useState(false);
  const [frontIdx, setFrontIdx] = useState<number | null>(null);
  const [coords, setCoords] = useState<[number, number][]>([]);

  function nearestEdgeIndex(lngLat: maplibregl.LngLat) {
    if (!mapRef.current || coords.length < 2) return null;
    const map = mapRef.current;
    let minD = Infinity, best: number | null = null;
    const p = map.project(lngLat);
    for (let i=0; i<coords.length-1; i++) {
      const a = map.project({lng: coords[i][0], lat: coords[i][1]} as any);
      const b = map.project({lng: coords[i+1][0], lat: coords[i+1][1]} as any);
      const vx = b.x - a.x, vy = b.y - a.y;
      const wx = p.x - a.x, wy = p.y - a.y;
      const c1 = vx*wx + vy*wy;
      const c2 = vx*vx + vy*vy;
      const t = c2>0 ? Math.max(0, Math.min(1, c1/c2)) : 0;
      const projx = a.x + t*vx, projy = a.y + t*vy;
      const dx = p.x - projx, dy = p.y - projy;
      const d = Math.hypot(dx, dy);
      if (d < minD) { minD = d; best = i; }
    }
    return best;
  }

  useEffect(()=>{
    if (mapRef.current || !mapContainer.current) return;
    const key = process.env.NEXT_PUBLIC_MAPTILER_KEY;
    const style = key
      ? `https://api.maptiler.com/maps/streets/style.json?key=${key}`
      : "https://demotiles.maplibre.org/style.json";

    const map = new maplibregl.Map({
      container: mapContainer.current,
      style,
      center: [-91.1403, 30.4515],
      zoom: 12,
      attributionControl: false
    });
    map.addControl(new maplibregl.NavigationControl({visualizePitch: true}), "bottom-right");
    const drawCtl = new MaplibreTerradrawControl({
      modes: ["polygon"],
      open: true,
      style: { fill: "rgba(56,189,248,0.2)", stroke: "rgba(56,189,248,1)" }
    });
    map.addControl(drawCtl, "top-right");
    map.on("td.create", (e:any)=>{
      const feat = e.detail?.features?.[0] as Feature<Polygon>;
      if (feat) {
        setSqft(Math.round(areaSqft(feat)));
        onChange(feat);
        setCoords(feat.geometry.coordinates[0] as any);
      }
    });
    map.on("td.update", (e:any)=>{
      const feat = e.detail?.features?.[0] as Feature<Polygon>;
      if (feat) {
        setSqft(Math.round(areaSqft(feat)));
        onChange(feat);
        setCoords(feat.geometry.coordinates[0] as any);
      }
    });
    map.on('idle', ()=>{
      try { const url = map.getCanvas().toDataURL('image/png'); onSnapshot?.(url); } catch {}
    });
    map.on('click', (e)=>{
      if (!frontMode) return;
      const idx = nearestEdgeIndex(e.lngLat);
      if (idx!=null) { setFrontIdx(idx); onFrontEdge?.(idx); }
    });
    mapRef.current = map;
    return ()=> map.remove();
  }, [onChange, onSnapshot, onFrontEdge, frontMode]);

  return (
    <div className="space-y-2">
      <div ref={mapContainer} className="w-full h-[420px] rounded-xl overflow-hidden border border-white/10" />
      <div className="flex items-center justify-between mt-2">
        <div className="text-sm text-white/70">{sqft ? <>Parcel area: <span className="font-medium text-white">{sqft.toLocaleString()}</span> sf</> : "Draw a parcel polygon to begin."}</div>
        <div className="flex items-center gap-2">
          <button onClick={()=> setFrontMode(m=>!m)} className={"btn " + (frontMode? "btn-primary":"btn-muted")}>{frontMode? "Click a street edge…":"Set Street Edge"}</button>
          {frontIdx!=null && <span className="text-xs text-white/70">Front edge set (#{frontIdx+1})</span>}
        </div>
      </div>
    </div>
  )
}
