export default function Logo({className=""}:{className?:string}) {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <div className="h-7 w-7 rounded-lg bg-gradient-to-br from-cyan-400 to-purple-500" />
      <span className="font-semibold tracking-tight">ParcelPilot</span>
    </div>
  );
}
