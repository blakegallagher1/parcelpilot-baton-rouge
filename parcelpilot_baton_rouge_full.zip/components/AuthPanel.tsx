'use client';
import { supabaseBrowser } from '@/lib/supabase-browser';
import { useEffect, useState } from 'react';

export default function AuthPanel() {
  const sb = supabaseBrowser();
  const [email, setEmail] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [credits, setCredits] = useState<number | null>(null);

  useEffect(()=>{
    const init = async () => {
      const { data: { session } } = await sb.auth.getSession();
      if (session?.user) {
        setEmail(session.user.email ?? null);
        const token = session.access_token;
        const res = await fetch('/api/me', { headers: { Authorization: `Bearer ${token}` } });
        const j = await res.json();
        if (j.ok) setCredits(j.credits);
      } else {
        setEmail(null);
      }
    };
    init();
    const { data: { subscription } } = sb.auth.onAuthStateChange((_event, session) => {
      setEmail(session?.user?.email ?? null);
    });
    return () => subscription.unsubscribe();
  }, [sb]);

  async function signInMagic() {
    const email = prompt('Enter your email to receive a magic link:');
    if (!email) return;
    setLoading(true);
    const { error } = await sb.auth.signInWithOtp({ email, options: { emailRedirectTo: window.location.origin + '/dashboard' } });
    setLoading(false);
    if (error) alert(error.message);
    else alert('Check your email for the magic link');
  }
  async function signInGoogle() {
    setLoading(true);
    const { error } = await sb.auth.signInWithOAuth({ provider: 'google', options: { redirectTo: window.location.origin + '/dashboard' } });
    setLoading(false);
    if (error) alert(error.message);
  }
  async function signOut() {
    await sb.auth.signOut();
    setEmail(null); setCredits(null);
  }

  return (
    <div className="flex items-center gap-3">
      {email ? (
        <>
          <div className="text-sm text-white/80">Signed in as <span className="font-medium">{email}</span>{credits!=null?` · ${credits} credits`:''}</div>
          <button onClick={signOut} className="btn btn-muted">Sign out</button>
        </>
      ) : (
        <>
          <button disabled={loading} onClick={signInGoogle} className="btn btn-muted">Sign in with Google</button>
          <button disabled={loading} onClick={signInMagic} className="btn btn-primary">Email Magic Link</button>
        </>
      )}
    </div>
  );
}
