import { NextRequest, NextResponse } from "next/server";
import { MODELS, genai } from "@/lib/gemini";
import { supabaseAdmin } from "@/lib/supabase";
import { directionalEnvelope } from "@/lib/envelope";

export const runtime = "nodejs";

function toBase64Url(b: Buffer) {
  return `data:image/png;base64,${b.toString('base64')}`;
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parcel = body?.parcel;
    const zoning = body?.zoning;
    const snapshot: string | null = body?.snapshot ?? null;
    const frontEdge: number | null = body?.frontEdge ?? null;
    if (!parcel || !zoning) return NextResponse.json({ ok:false, error: "Missing parcel/zoning" }, { status: 400 });

    // Auth
    const auth = req.headers.get("authorization");
    const token = auth?.split("Bearer ")[1];
    if (!token) return NextResponse.json({ ok:false, error: "Unauthorized" }, { status: 401 });
    const sb = supabaseAdmin();
    const { data: userData } = await sb.auth.getUser(token);
    const user = userData?.user;
    if (!user) return NextResponse.json({ ok:false, error: "Unauthorized" }, { status: 401 });

    // Credits
    const { data: row } = await sb.from("credits").select("balance").eq("user_id", user.id).single();
    const balance = (row?.balance ?? 0);
    if (balance < 1) return NextResponse.json({ ok:false, error: "Not enough credits" }, { status: 402 });
    await sb.from("credits").update({ balance: balance - 1 }).eq("user_id", user.id);

    // Optional directional envelope
    let envelopeJson: any = null;
    try { if (frontEdge!=null) envelopeJson = directionalEnvelope(parcel, frontEdge, zoning.setbacks); } catch {}

    const ai = genai();
    const model = ai.getGenerativeModel({ model: MODELS.IMAGE });

    const prompt = `You are generating a clean, top-down conceptual site plan from a parcel polygon and zoning rules.
Render a 2D site plan with:
- bold property boundary
- dashed interior setbacks (front/side/rear per inputs)
- practical building footprints within envelope/FAR
- surface parking (9x18 ft stalls, 24 ft aisles), driveways, walks
- minimal landscaping, north arrow, scale bar (assume 1\" = 40')
Style: architectural site plan, legible labels, thin lines, muted palette.

Inputs (additional JSON parts may follow):
- PARCEL_GEOJSON
- ZONING object with setbacks (ft), optional FAR/height
- Optional BUILDABLE_ENVELOPE_GEOJSON for tighter placement
If a 'front edge' index is provided, align the dashed 'front' setback on that edge, with opposite edge as 'rear'.`;

    const parts: any[] = [{ text: prompt },
                           { text: "PARCEL_GEOJSON:\n" + JSON.stringify(parcel).slice(0,6000) },
                           { text: "ZONING:\n" + JSON.stringify(zoning) }];
    if (envelopeJson) parts.push({ text: "BUILDABLE_ENVELOPE_GEOJSON:\n" + JSON.stringify(envelopeJson).slice(0,6000) });
    if (snapshot && snapshot.startsWith('data:image')) {
      const base64 = snapshot.split(',')[1];
      parts.push({ inlineData: { mimeType: 'image/png', data: base64 } });
    }

    const response = await model.generateContent({
      contents: [{ role: "user", parts }]
    });

    const candidates: any = response.response.candidates;
    const part = candidates?.[0]?.content?.parts?.find((p:any)=>p.inlineData);
    if (!part?.inlineData?.data) {
      return NextResponse.json({ ok:false, error: "No image returned" }, { status: 500 });
    }
    const b64 = Buffer.from(part.inlineData.data, "base64");
    const dataUrl = toBase64Url(b64);

    // Save to Supabase Storage
    let publicUrl = dataUrl;
    try {
      const bucket = "siteplans";
      const filename = `plan_${Date.now()}.png`;
      const { data, error } = await sb.storage.from(bucket).upload(filename, b64, {
        contentType: "image/png",
        upsert: false
      });
      if (!error && data) {
        const { data: urlData } = sb.storage.from(bucket).getPublicUrl(filename);
        if (urlData?.publicUrl) publicUrl = urlData.publicUrl;
      }
    } catch {}

    return NextResponse.json({ ok:true, imageUrl: publicUrl });
  } catch (e:any) {
    console.error(e);
    return NextResponse.json({ ok:false, error: e.message }, { status: 500 });
  }
}
