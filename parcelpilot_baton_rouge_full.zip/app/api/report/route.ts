import { NextRequest, NextResponse } from "next/server";
export const runtime = "nodejs";
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const image = searchParams.get("image");
  const html = `<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>ParcelPilot Report</title>
  <style>
    body { font-family: ui-sans-serif, system-ui; margin: 24px; }
    h1 { margin: 0 0 4px; }
    .meta { color: #555; margin-bottom: 16px;}
    img { max-width: 100%; border: 1px solid #ccc; border-radius: 8px; }
  </style>
</head>
<body>
  <h1>ParcelPilot – Site Plan</h1>
  <div class="meta">${new Date().toLocaleString()}</div>
  ${image ? `<img src="${image}" />` : "<p>No image</p>"}
  <p style="margin-top:12px;font-size:12px;color:#666">Conceptual only. Not for construction or permitting.</p>
</body>
</html>`;
  return new NextResponse(html, {
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Content-Disposition": "attachment; filename=parcelpilot_report.html"
    }
  });
}
