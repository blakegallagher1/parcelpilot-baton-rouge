import { GoogleGenerativeAI } from "@google/generative-ai";

export function genai() {
  const key = process.env.GEMINI_API_KEY;
  if (!key) throw new Error("Missing GEMINI_API_KEY");
  return new GoogleGenerativeAI(key);
}
export const MODELS = {
  TEXT: "gemini-2.5-flash",
  IMAGE: "gemini-2.5-flash-image-preview"
} as const;
