export type ZoningPreset = {
  code: string;
  label: string;
  city: string;
  source: string;
  defaults: {
    setbacks: { frontFt:number; sideFt:number; rearFt:number; };
    maxHeightFt?: number | null;
    far?: number | null;
    lotCoveragePct?: number | null;
    parkingRatioPer1000sf?: number | null;
  };
  notes?: string;
};

export const BR_PRESETS: ZoningPreset[] = [
  { code: "LC1", label: "LC1 – Light Commercial One", city: "Baton Rouge / EBR", source: "UDC Ch.11 Table 11.G (Dec 2021)",
    defaults: { setbacks: {frontFt:10, sideFt:0, rearFt:0}, maxHeightFt:45, far:null, lotCoveragePct:null, parkingRatioPer1000sf:4 },
    notes: "Corner side 10 ft; height may increase per §11.1.3.B.3." },
  { code: "LC2", label: "LC2 – Light Commercial Two", city: "Baton Rouge / EBR", source: "UDC Ch.11 Table 11.G (Dec 2021)",
    defaults: { setbacks: {frontFt:10, sideFt:0, rearFt:0}, maxHeightFt:45, far:null, lotCoveragePct:null, parkingRatioPer1000sf:4 } },
  { code: "LC3", label: "LC3 – Light Commercial Three", city: "Baton Rouge / EBR", source: "UDC Ch.11 Table 11.G (Dec 2021)",
    defaults: { setbacks: {frontFt:10, sideFt:0, rearFt:0}, maxHeightFt:45, far:null, lotCoveragePct:null, parkingRatioPer1000sf:4 } },
  { code: "HC1", label: "HC1 – Heavy Commercial One", city: "Baton Rouge / EBR", source: "UDC Ch.11 Table 11.G (Dec 2021)",
    defaults: { setbacks: {frontFt:10, sideFt:0, rearFt:0}, maxHeightFt:75, far:null, lotCoveragePct:null, parkingRatioPer1000sf:4 } },
  { code: "HC2", label: "HC2 – Heavy Commercial Two", city: "Baton Rouge / EBR", source: "UDC Ch.11 Table 11.G (Dec 2021)",
    defaults: { setbacks: {frontFt:10, sideFt:0, rearFt:0}, maxHeightFt:75, far:null, lotCoveragePct:null, parkingRatioPer1000sf:4 } },
  { code: "C5", label: "C5 – Central Business District", city: "Baton Rouge / EBR", source: "UDC Ch.11 Table 11.G (Dec 2021)",
    defaults: { setbacks: {frontFt:0, sideFt:0, rearFt:0}, maxHeightFt:180, far:null, lotCoveragePct:null, parkingRatioPer1000sf:2 },
    notes: "No yards required; see §11.1.3.B.4 for height." },
  { code: "NO", label: "NO – Neighborhood Office", city: "Baton Rouge / EBR", source: "UDC Ch.11 Table 11.G (Dec 2021)",
    defaults: { setbacks: {frontFt:20, sideFt:5, rearFt:25}, maxHeightFt:35, far:null, lotCoveragePct:null, parkingRatioPer1000sf:4 } },
  { code: "NC", label: "NC – Neighborhood Commercial", city: "Baton Rouge / EBR", source: "UDC Ch.11 Table 11.G (Dec 2021)",
    defaults: { setbacks: {frontFt:20, sideFt:5, rearFt:25}, maxHeightFt:35, far:null, lotCoveragePct:null, parkingRatioPer1000sf:4 } },
  { code: "C1", label: "C1 – Commercial One (Inactive)", city: "Baton Rouge / EBR", source: "UDC Ch.11 Table 11.G (Dec 2021)",
    defaults: { setbacks: {frontFt:10, sideFt:0, rearFt:0}, maxHeightFt:45, far:null, lotCoveragePct:null, parkingRatioPer1000sf:4 } },
  { code: "C2", label: "C2 – Commercial Two (Inactive)", city: "Baton Rouge / EBR", source: "UDC Ch.11 Table 11.G (Dec 2021)",
    defaults: { setbacks: {frontFt:10, sideFt:0, rearFt:0}, maxHeightFt:45, far:null, lotCoveragePct:null, parkingRatioPer1000sf:4 } },
  { code: "C-AB-1", label: "C‑AB‑1 – Alcoholic Beverage (follows underlying)", city: "Baton Rouge / EBR", source: "UDC §11.2.8.B",
    defaults: { setbacks: {frontFt:10, sideFt:0, rearFt:0}, maxHeightFt:null, far:null, lotCoveragePct:null, parkingRatioPer1000sf:4 } },
  { code: "C-AB-2", label: "C‑AB‑2 – Alcoholic Beverage (follows underlying)", city: "Baton Rouge / EBR", source: "UDC §11.2.8.B",
    defaults: { setbacks: {frontFt:10, sideFt:0, rearFt:0}, maxHeightFt:null, far:null, lotCoveragePct:null, parkingRatioPer1000sf:4 } }
];

export function getPreset(code: string) {
  return BR_PRESETS.find(p => p.code.toUpperCase() === code.toUpperCase()) || null;
}
